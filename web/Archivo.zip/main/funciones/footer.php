<?php

function getFooter(){

  $resultado = '
      <footer class="main-footer">
      <!-- To the right -->
      <div class="pull-right hidden-xs">
      proyecto de titulo INACAP 2018
      </div>
      <!-- Default to the left -->
      <strong>Copyright &copy; tuClinic 2018 <a href="#">tuClinic</a>.</strong> Todos los derechos reservados
      </footer>



  ';

  return $resultado;

}



 ?>
