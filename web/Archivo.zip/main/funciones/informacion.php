<?php


function getInformacion(){
  
}


?>
